import React, { useState, useEffect } from "react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Leaf, Home, User, Users, PiggyBank, Car, Coins, Zap, Globe } from "lucide-react";

const ecoPalette = [
  "#13A449",
  "#3ECEF7",
  "#62D293",
  "#AAD7AA",
  "#C7F2DF",
  "#59B3C0",
  "#5C96B6",
];

const formatMoney = (v) => Number(v || 0).toLocaleString("it-IT");

const cardClass =
  "bg-white dark:bg-[#212d23] rounded-3xl shadow-xl mb-8 p-6 md:p-8 transition-all duration-300";
const labelStyle =
  "inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-green-50 dark:bg-[#19331e] text-green-800 dark:text-green-200 text-xs font-semibold tracking-wide uppercase mb-1";
const numberStyle = "font-extrabold tracking-tight text-3xl md:text-4xl mb-2 text-green-700 dark:text-green-200";
const tableCellClass = "px-4 py-2";
const sectionTitle = "font-bold text-green-800 dark:text-green-200 text-lg my-4 uppercase tracking-wider flex items-center gap-2";

function FamilyHeader({ title = "Bilancio Familiare", subtitleDate = "Pensaci e Risparmia" }) {
  return (
    <header className="flex flex-col md:flex-row justify-between items-center gap-6 p-6 rounded-2xl mb-6 bg-gradient-to-r from-green-50 to-blue-50 dark:from-[#19331e] dark:to-[#112930] border border-green-100 dark:border-[#1a3e1f] shadow-md transition-all">
      <div className="flex items-center gap-3">
        <Users size={38} className="text-green-700 dark:text-green-300" aria-label="Famiglia" />
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-green-900 dark:text-green-100">{title}</h1>
          <div className="text-xs md:text-sm text-green-600 dark:text-green-100 font-semibold flex items-center gap-2 mt-1">
            Famiglia tipo <span className="inline-flex items-center ml-1 gap-1"><User size={16} /><User size={16} />+<User size={14} /> <User size={14} /></span> &nbsp;|&nbsp; 
            <span>{subtitleDate}</span>
          </div>
        </div>
      </div>
      <Leaf size={40} className="text-green-400 dark:text-green-400 drop-shadow-[0_2px_6px_rgba(30,200,134,0.19)]" aria-label="Eco leaf" />
    </header>
  );
}

function DataTable({ title, data, onChange, showTotal = false, totalLabel = "Totale", iconTitle }) {
  const handleChange = (idx, field, value) => {
    if (!onChange) return;
    const copy = data.map((r) => ({ ...r }));
    copy[idx][field] = field === "value" ? Number(value) : value;
    onChange(copy);
  };

  const handleAdd = () => {
    if (!onChange) return;
    onChange([...(data || []), { key: "Nuovo elemento", value: 0 }]);
  };

  const handleRemove = (idx) => {
    if (!onChange) return;
    const copy = data.filter((_, i) => i !== idx);
    onChange(copy);
  };

  return (
    <div className={cardClass} role="region" aria-labelledby={title.replace(" ", "-")}>
      <div className={sectionTitle}>
        {iconTitle} {title}
      </div>
      <table className="w-full border-separate border-spacing-y-2 text-green-900 dark:text-green-100">
        <tbody>
          {(data || []).map(({ key, value }, i) => (
            <tr key={`${key}-${i}`} className="align-middle">
              <td className={tableCellClass + " font-medium flex items-center gap-2"}>
                {onChange ? (
                  <input aria-label={`label-${i}`} className="w-full bg-transparent border-b border-transparent focus:border-green-300 focus:outline-none" value={key} onChange={(e)=>handleChange(i,'key',e.target.value)} />
                ) : (
                  <span>{key}</span>
                )}
              </td>
              <td className={tableCellClass + " text-right font-mono font-bold tracking-wide w-32"}>
                {onChange ? (
                  <input aria-label={`value-${i}`} type="number" className="w-full text-right bg-transparent border-b border-transparent focus:border-green-300 focus:outline-none" value={value} onChange={(e)=>handleChange(i,'value',e.target.value)} />
                ) : (
                  <span>{formatMoney(value)} €</span>
                )}
              </td>
              {onChange && (
                <td className="pr-2">
                  <button className="text-xs px-2 py-1 rounded-lg bg-red-50 dark:bg-red-900 text-red-700 dark:text-red-200" onClick={()=>handleRemove(i)} aria-label={`rimuovi-${i}`}>Rimuovi</button>
                </td>
              )}
            </tr>
          ))}
          {showTotal && (
            <tr>
              <td className={tableCellClass + " font-bold uppercase"}>{totalLabel}</td>
              <td className={tableCellClass + " text-right font-extrabold tracking-wider text-green-700 dark:text-green-200"}>{formatMoney((data||[]).reduce((a,b)=>a+(Number(b.value)||0),0))} €</td>
              <td></td>
            </tr>
          )}
        </tbody>
      </table>
      {onChange && (
        <div className="mt-4 flex gap-2">
          <button onClick={handleAdd} className="px-3 py-2 rounded-xl bg-green-600 text-white text-sm font-semibold">Aggiungi</button>
        </div>
      )}
    </div>
  );
}

function NetWorthBox({ assets, liabilities }) {
  const totalAssets = (assets || []).reduce((a,b)=>a+(Number(b.value)||0),0);
  const totalLiabilities = (liabilities || []).reduce((a,b)=>a+(Number(b.value)||0),0);
  const netWorth = totalAssets - totalLiabilities;
  return (
    <div className="w-full">
      <div className="mx-auto flex flex-col items-center justify-center rounded-2xl bg-gradient-to-br from-green-200 via-blue-100 to-white dark:from-[#142e1d] dark:via-[#1b3563] dark:to-[#112930] border-2 border-green-300 dark:border-green-700 shadow-lg p-8 mb-10"
        aria-live="polite">
        <div className={labelStyle + " mb-2"}><PiggyBank size={22} /> Patrimonio Netto</div>
        <div className={numberStyle}>{formatMoney(netWorth)} €</div>
        <span className="text-green-700 dark:text-green-100 text-sm tracking-widest uppercase font-bold">Ricchezza familiare</span>
      </div>
    </div>
  );
}

function OperatingResultBox({ incomes, expenses }) {
  const totalIncome = (incomes||[]).reduce((a,b)=>a+(Number(b.value)||0),0);
  const totalExpenses = (expenses||[]).reduce((a,b)=>a+(Number(b.value)||0),0);
  const operatingResult = totalIncome - totalExpenses;
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl bg-gradient-to-br from-green-100 via-blue-50 to-white dark:from-[#1b381f] dark:via-[#132947] dark:to-[#112930] border-2 border-blue-200 dark:border-blue-800 shadow p-8 mb-10 mx-auto transition-transform group hover:scale-105">
      <div className={labelStyle + " mb-2"}>
        <Coins size={20} /> Risultato d'esercizio
      </div>
      <div className={numberStyle}>{formatMoney(operatingResult)} €</div>
      <span className="text-blue-800 dark:text-blue-100 text-xs uppercase font-semibold tracking-widest">Differenza entrate/uscite | 2024</span>
    </div>
  );
}

function ExpensePieChart({ expenses }) {
  return (
    <div className={cardClass + " min-h-[380px] flex flex-col items-center"} role="region" aria-labelledby="spese-categorie">
      <div className={sectionTitle}><PieChart width={20} height={20} /> Spese per categoria</div>
      <ResponsiveContainer width="100%" height={240}>
        <PieChart>
          <Pie data={expenses} cx="50%" cy="50%" labelLine={false} outerRadius={90} dataKey="value" nameKey="key" fill="#62D293" label={({ percent, name }) => `${name} (${(percent * 100).toFixed(1)}%)`}>
            {(expenses || []).map((entry, idx) => (
              <Cell key={`cell-${idx}`} fill={ecoPalette[idx % ecoPalette.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value) => `${formatMoney(value)} €`} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
      <div className="flex flex-wrap gap-3 justify-center mt-3">
        {(expenses||[]).map((e) => (
          <div key={e.key} className="flex items-center gap-1 col-span-1 text-xs text-green-800 dark:text-green-100">
            <span className="w-4 h-4 inline-block rounded-sm" style={{ background: ecoPalette[Math.abs(e.key.length) % ecoPalette.length] }} /> {e.key}
          </div>
        ))}
      </div>
    </div>
  );
}

function RevenueVsExpenseBarChart({ incomes, expenses }) {
  const totalIncome = (incomes||[]).reduce((a,b)=>a+(Number(b.value)||0),0);
  const totalExpenses = (expenses||[]).reduce((a,b)=>a+(Number(b.value)||0),0);
  const data = [{ name: "Entrate", value: totalIncome, fill: "#13A449" }, { name: "Uscite", value: totalExpenses, fill: "#3ECEF7" }];
  return (
    <div className={cardClass + " min-h-[300px] flex flex-col items-center"} role="region" aria-labelledby="entrate-vs-uscite">
      <div className={sectionTitle}>
        <BarChart width={20} height={20} /> Entrate vs Uscite
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={data} margin={{ left: 8, right: 40, top: 12, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" tick={{ fontSize: 13, fontWeight: 600 }} />
          <YAxis tickFormatter={(v) => v.toLocaleString("it-IT")} axisLine={false} tick={{ fontSize: 13, fontWeight: 600 }} />
          <Tooltip formatter={(val) => `${formatMoney(val)} €`} />
          <Bar dataKey="value" radius={[8, 8, 0, 0]}>
            {data.map((entry, idx) => (
              <Cell key={`barcell-${idx}`} fill={entry.fill} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div className="flex gap-8 py-2">
        <div className="flex flex-col items-center">
          <span className="text-green-700 dark:text-green-200 font-bold">{formatMoney(data[0].value)} €</span>
          <span className="text-xs text-green-800 dark:text-green-100">Entrate</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-blue-700 dark:text-blue-200 font-bold">{formatMoney(data[1].value)} €</span>
          <span className="text-xs text-blue-900 dark:text-blue-100">Uscite</span>
        </div>
      </div>
    </div>
  );
}

function Controls({ onGenerate, onReset, onExport }) {
  return (
    <div className="flex gap-3 items-center justify-end mb-6">
      <button className="px-4 py-2 rounded-xl bg-gray-100 dark:bg-[#0f2214] text-sm font-semibold" onClick={onReset}>Reset</button>
      <button className="px-4 py-2 rounded-xl bg-green-600 text-white text-sm font-semibold" onClick={onGenerate}>Genera bilancio</button>
      <button className="px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold" onClick={onExport}>Esporta (stampa/PDF)</button>
    </div>
  );
}

export default function App({ initialState }) {
  const defaultState = initialState || {
    assets: [
      { key: "Casa di proprietà", value: 200000 },
      { key: "Auto di proprietà", value: 25000 },
      { key: "Investimenti", value: 15000 },
    ],
    liabilities: [
      { key: "Mutuo residuo", value: 120000 },
      { key: "Rate auto residue", value: 10000 },
      { key: "Bollette luce/gas", value: 600 },
    ],
    incomes: [
      { key: "Redditi da lavoro netti", value: 45000 },
    ],
    expenses: [
      { key: "Supermercati", value: 6000 },
      { key: "Casa/tasse/manutenzioni", value: 2000 },
      { key: "Viaggi", value: 6000 },
      { key: "Rate auto", value: 2400 },
      { key: "Rate mutuo", value: 6000 },
      { key: "Bollette luce/gas", value: 2500 },
      { key: "Internet/telefonia/abbonamenti", value: 1200 },
    ],
    title: "Bilancio Familiare",
    subtitleDate: "Pensaci e Risparmia",
  };

  const [assets, setAssets] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bilancio_assets")) || defaultState.assets; } catch { return defaultState.assets; }
  });
  const [liabilities, setLiabilities] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bilancio_liabilities")) || defaultState.liabilities; } catch { return defaultState.liabilities; }
  });
  const [incomes, setIncomes] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bilancio_incomes")) || defaultState.incomes; } catch { return defaultState.incomes; }
  });
  const [expenses, setExpenses] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bilancio_expenses")) || defaultState.expenses; } catch { return defaultState.expenses; }
  });
  const [title, setTitle] = useState(defaultState.title);
  const [subtitleDate, setSubtitleDate] = useState(defaultState.subtitleDate);

  useEffect(()=>{ localStorage.setItem("bilancio_assets", JSON.stringify(assets)); },[assets]);
  useEffect(()=>{ localStorage.setItem("bilancio_liabilities", JSON.stringify(liabilities)); },[liabilities]);
  useEffect(()=>{ localStorage.setItem("bilancio_incomes", JSON.stringify(incomes)); },[incomes]);
  useEffect(()=>{ localStorage.setItem("bilancio_expenses", JSON.stringify(expenses)); },[expenses]);

  const handleReset = () => {
    if (confirm("Vuoi resettare tutti i dati del bilancio?")) {
      setAssets(defaultState.assets);
      setLiabilities(defaultState.liabilities);
      setIncomes(defaultState.incomes);
      setExpenses(defaultState.expenses);
      localStorage.removeItem("bilancio_assets");
      localStorage.removeItem("bilancio_liabilities");
      localStorage.removeItem("bilancio_incomes");
      localStorage.removeItem("bilancio_expenses");
    }
  };

  const handleExport = () => {
    window.print();
  };

  const handleGenerate = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen py-4 md:py-10 px-2 md:px-0 bg-gradient-to-br from-green-50 to-blue-50 dark:from-[#102314] dark:to-[#10203b] print:bg-white">
      <div className="max-w-3xl mx-auto">
        <FamilyHeader title={title} subtitleDate={subtitleDate} />

        <div className="mb-4 flex gap-2">
          <input value={title} onChange={(e)=>setTitle(e.target.value)} className="flex-1 rounded-lg p-2 border border-transparent focus:border-green-200" />
          <input value={subtitleDate} onChange={(e)=>setSubtitleDate(e.target.value)} className="w-40 rounded-lg p-2 border border-transparent focus:border-green-200" />
        </div>

        <Controls onGenerate={handleGenerate} onReset={handleReset} onExport={handleExport} />

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <DataTable title="Attività" data={assets} onChange={setAssets} showTotal totalLabel="Totale attività" iconTitle={<PiggyBank />} />
          <DataTable title="Passività" data={liabilities} onChange={setLiabilities} showTotal totalLabel="Totale passività" iconTitle={<Zap />} />
        </div>

        <NetWorthBox assets={assets} liabilities={liabilities} />

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <DataTable title="Entrate" data={incomes} onChange={setIncomes} showTotal={false} iconTitle={<Coins />} />
          <DataTable title="Uscite" data={expenses} onChange={setExpenses} showTotal totalLabel="Totale uscite" iconTitle={<Globe />} />
        </div>

        <OperatingResultBox incomes={incomes} expenses={expenses} />

        <div className="grid md:grid-cols-2 gap-6">
          <ExpensePieChart expenses={expenses} />
          <RevenueVsExpenseBarChart incomes={incomes} expenses={expenses} />
        </div>

        <footer className="pt-8 pb-4 flex justify-center text-xs text-green-900 dark:text-green-100 opacity-80 print:hidden">
          <span>
            <Leaf size={14} className="inline mr-1" /> DEMO - Pensaci e Risparmia | Eco Bilancio Familiare
          </span>
        </footer>
      </div>
    </div>
  );
}
