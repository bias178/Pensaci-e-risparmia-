# Bilancio Familiare - Vercel-ready ZIP

Istruzioni rapide:
1. Scarica questo file ZIP ed estrailo.
2. Vai su https://vercel.com/dashboard → Add New Project → Import → Upload
3. Trascina l'intera cartella estratta oppure il file ZIP.
4. Premi Deploy: Vercel installerà e buildarà automaticamente (usa `npm install` e `npm run build`).
5. Dopo il deploy, copia il link (es. `https://bilancio-familiare.vercel.app`) e incollalo nella tua pagina WordPress dentro un iframe:
   `<iframe src="https://tuo-deploy.vercel.app" width="100%" height="1200" style="border:none"></iframe>`

Note:
- Il progetto usa Vite + React + Tailwind + Recharts.
- È già in italiano e ha dark mode automatica.
- Salvataggio dati avviene via localStorage (nessun dato lascia il browser).
